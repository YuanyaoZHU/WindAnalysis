% LIMITATIONS (+)  WAFO known limitations
%
%  (1) Time: Some of the routines may take a while to execute 
%      depending on the dimension of the problem and parameter values given.
%      (E.g. all the functions in the trgauss directory)
%
%  (2) Generally, we do not check to see if input parameters
%      are reasonable. 
%
%  (3) Some functions may have limited usability, i.e. can not
%      handle every type of arguments even tough its name indicate so.
%      This is hopefully accomplished in some future releases.

% (+) Other limitations?

% History
% By pab 09.09.1999
%
more on
help limitations
more off
