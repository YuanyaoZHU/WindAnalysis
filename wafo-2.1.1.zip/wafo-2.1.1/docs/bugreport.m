% BUGREPORT Bug Report Form for WAFO
%
%  Please fill out the following form and submit it as
%  your report of a problem:
%
%  Title of Problem:                        (e.g. Function XXXXX makes Mistake)
%
%  Name of Submitter:
%  e-mail of Submitter:
%
%  Version of WAFO:
%  Machine Architecture (PC,Mac,Unix):
%
%  Short description of problem:
%
%
%
%
%
%  Submit programming code which reproduces the problem here:
%  
%
%
%  Specify  here which file causes the problem:
%
%
%
%
%  If possible, suggest a fix for problem here.
%
%
%
%
%  Thanks for your cooperation!
%

%history:
% by pab 14.12.1999 
   
more on
help bugreport
more off
