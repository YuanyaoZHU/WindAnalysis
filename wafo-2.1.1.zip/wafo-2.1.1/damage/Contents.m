% Module DAMAGE in WAFO Toolbox. 
% Version 2.1.1  07-Sep-2005 
% 
%
% This module contains routines connected to fatigue damage calculations.
% 
% The routines are described in the contents of 'Fatigue in WAFO'.
% Try 'help fatigue'.
