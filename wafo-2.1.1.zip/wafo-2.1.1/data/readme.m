%README Readme file for module DATA in  WAFO Toolbox.
%
% Version 2.1.1   07-Nov-2004
%
%  ENHANCEMENTS
%  ~~~~~~~~~~~~~ 
%   Enhanced the examples in northsea.m and japansea.m  
%   with commands to the m_map toolbox (see http://www.ocgy.ubc.ca/~rich/)
