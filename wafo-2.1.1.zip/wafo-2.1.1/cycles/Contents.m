% Module CYCLES in WAFO Toolbox. 
% Version 2.1.1   06-Sep-2005 
%
%
% This module contains routines for cycle counting, discretization, 
% and crossings.
% 
% The routines are described in the contents of 'Fatigue in WAFO'.
% Try 'help fatigue'.
